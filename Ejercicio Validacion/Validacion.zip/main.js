var validacionNombre = 0;
var validacionApellido= 0;
var validacionMail= 0;
var validacionPassword= 0;
var validacionRPassword = 0;
var validacionDni= 0;
var validacionIpEquipo = 0;
var arrValidacion = new Array();

function validarNombre(){
    patternName = /[0-9]/g;
    if(patternName.test(document.getElementById("name").value)){
        document.getElementById("name").style.background="red";
        arrValidacion[0] = false;
    }else{
        document.getElementById("name").style.background="";
        arrValidacion[0] = true;
    }
}
function validarApellidos(){
    patternSurName = /[0-9]/g;
    
    if(patternSurName.test(document.getElementById("surname").value)){
        document.getElementById("surname").style.background="red";
        arrValidacion[1] = false;
    }else{
        document.getElementById("surname").style.background="";
        arrValidacion[1] = true;
    }
}
function validarMail(){
    patternMail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/g;

    if(patternMail.test(document.getElementById("mail").value)){
        document.getElementById("mail").style.background="";
        arrValidacion[2] = true;
    }else{
        document.getElementById("mail").style.background="red";
        arrValidacion[2] = false;
    }
}
function validarDni(){
    patternDni = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/i;

    if(patternDni.test(document.getElementById("dni").value)){
        document.getElementById("dni").style.background="";
        arrValidacion[3] = true;
    }else{
        document.getElementById("dni").style.background="red";
        arrValidacion[3] = false;
    }
}
function validarPassword(){
    patternPassword = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/g;

    if(patternPassword.test(document.getElementById("password").value)){
        document.getElementById("password").style.background="";
        arrValidacion[4] = true;
    }else{
        document.getElementById("password").style.background="red";
        arrValidacion[4] = false;
    }
}
function validarRPassword(){

    p = document.getElementById("password").value;
    rp = document.getElementById("rpassword").value;

    if(p!=rp){
        document.getElementById("rpassword").style.background="red";
        arrValidacion[5] = false;
    }else{
        document.getElementById("rpassword").style.background="";
        arrValidacion[5] = true;
    }
}

function validarIpEquipo(){
    patternIpEquipo = /[0-9]/g;

    if(patternIpEquipo.test(document.getElementById("ipequipo").value)){
        document.getElementById("ipequipo").style.background="red";
        arrValidacion[6] = false;
    }else{
        document.getElementById("ipequipo").style.background="";
        arrValidacion[6] = true;
    }
}
function validarFormulario(){
        
        if(arrValidacion[0]==false){
            console.log("El campo nombre está mal");
        }
        if(arrValidacion[1]==false){
            console.log("El campo apellido está mal");
        }
        if(arrValidacion[2]==false){
            console.log("El campo mail está mal");
        }
        if(arrValidacion[3]==false){
            console.log("El campo dni está mal");
        }
        if(arrValidacion[4]==false){
            console.log("El campo password está mal");
        }
        if(arrValidacion[5]==false){
            console.log("El campo repetir password está mal");
        }
        if(arrValidacion[6]==false){
            console.log("El campo IP Equipo está mal");
        }
        x = arrValidacion.indexOf(false);
        if(x == -1){
            console.log("Todo correcto");
        }

}